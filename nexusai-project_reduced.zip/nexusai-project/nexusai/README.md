# NexusAI — Enterprise GenAI Chatbot

A production-grade AI chatbot platform built with **FastAPI + React + Claude**.

## Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| AI        | Anthropic Claude (claude-sonnet-4)|
| Backend   | FastAPI, SQLAlchemy, PostgreSQL    |
| Auth      | JWT (bcrypt passwords)            |
| Frontend  | React 18, TypeScript, Tailwind    |
| State     | Zustand                           |
| Infra     | Docker Compose, Redis             |

## Project Structure

```
nexusai/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app entry point
│   │   ├── core/
│   │   │   ├── config.py        # Settings from env vars
│   │   │   ├── database.py      # Async SQLAlchemy setup
│   │   │   └── security.py      # JWT auth helpers
│   │   ├── api/routes/
│   │   │   ├── auth.py          # Login / register
│   │   │   ├── chat.py          # Send message, history, streaming
│   │   │   ├── sessions.py      # CRUD for chat sessions
│   │   │   └── health.py        # Health check
│   │   ├── models/
│   │   │   ├── models.py        # SQLAlchemy ORM models
│   │   │   └── schemas.py       # Pydantic request/response schemas
│   │   ├── services/
│   │   │   └── ai_service.py    # Claude API wrapper
│   │   └── middleware/
│   │       ├── logging.py       # Request logging
│   │       └── rate_limit.py    # Per-IP rate limiting
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── App.tsx              # Router + protected routes
│   │   ├── pages/
│   │   │   ├── ChatPage.tsx     # Main chat UI
│   │   │   └── LoginPage.tsx    # Auth screen
│   │   ├── hooks/
│   │   │   └── useChat.ts       # Chat business logic hook
│   │   ├── services/
│   │   │   └── api.ts           # Axios client + all API calls
│   │   └── store/
│   │       └── index.ts         # Zustand global state
│   ├── package.json
│   └── .env.example
│
└── docker-compose.yml
```

## Quick Start

### 1. Clone and configure

```bash
cp backend/.env.example backend/.env
# Edit backend/.env — add your ANTHROPIC_API_KEY

cp frontend/.env.example frontend/.env
```

### 2. Run with Docker

```bash
docker-compose up --build
```

- Frontend: http://localhost:5173
- Backend API docs: http://localhost:8000/api/docs

### 3. Run locally (without Docker)

**Backend:**
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in your API key
uvicorn app.main:app --reload
```

**Frontend:**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

## API Endpoints

| Method | Path                        | Description           |
|--------|-----------------------------|-----------------------|
| POST   | /api/auth/register          | Create account        |
| POST   | /api/auth/login             | Get JWT token         |
| GET    | /api/sessions/              | List user sessions    |
| POST   | /api/sessions/              | Create session        |
| DELETE | /api/sessions/{id}          | Delete session        |
| POST   | /api/chat/message           | Send message          |
| GET    | /api/chat/{id}/history      | Get message history   |
| POST   | /api/chat/{id}/stream       | SSE streaming         |
| GET    | /api/health                 | Health check          |

## MNC-Standard Features

- JWT authentication with role-based access
- Async database with connection pooling
- Per-IP rate limiting (30 req/min, configurable)
- Structured request logging with latency
- Token usage tracking per message
- Optimistic UI updates
- Conversation context window management (last 20 messages)
- SSE streaming endpoint for real-time responses
- Docker-ready for Kubernetes deployment
