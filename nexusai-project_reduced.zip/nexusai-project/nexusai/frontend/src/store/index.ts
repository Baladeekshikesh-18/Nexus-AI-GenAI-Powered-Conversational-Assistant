/**
 * Zustand global store — auth state + chat state.
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  input_tokens: number;
  output_tokens: number;
  latency_ms: number;
  created_at: string;
}

export interface Session {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

interface AuthState {
  token: string | null;
  user: { user_id: string; email: string; full_name: string; role: string } | null;
  setAuth: (token: string, user: AuthState['user']) => void;
  logout: () => void;
}

interface ChatState {
  sessions: Session[];
  activeSessionId: string | null;
  messages: Record<string, Message[]>;  // keyed by session_id
  isLoading: boolean;
  setSessions: (sessions: Session[]) => void;
  setActiveSession: (id: string) => void;
  addSession: (session: Session) => void;
  removeSession: (id: string) => void;
  setMessages: (sessionId: string, messages: Message[]) => void;
  appendMessage: (sessionId: string, message: Message) => void;
  updateSessionTitle: (id: string, title: string) => void;
  setLoading: (v: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      setAuth: (token, user) => {
        localStorage.setItem('access_token', token);
        set({ token, user });
      },
      logout: () => {
        localStorage.removeItem('access_token');
        set({ token: null, user: null });
      },
    }),
    { name: 'nexusai-auth' }
  )
);

export const useChatStore = create<ChatState>()((set) => ({
  sessions: [],
  activeSessionId: null,
  messages: {},
  isLoading: false,
  setSessions:      (sessions)           => set({ sessions }),
  setActiveSession: (id)                 => set({ activeSessionId: id }),
  addSession:       (session)            => set((s) => ({ sessions: [session, ...s.sessions] })),
  removeSession:    (id)                 => set((s) => ({ sessions: s.sessions.filter((x) => x.id !== id) })),
  setMessages:      (sid, messages)      => set((s) => ({ messages: { ...s.messages, [sid]: messages } })),
  appendMessage:    (sid, message)       => set((s) => ({
    messages: { ...s.messages, [sid]: [...(s.messages[sid] ?? []), message] },
  })),
  updateSessionTitle: (id, title)        => set((s) => ({
    sessions: s.sessions.map((x) => (x.id === id ? { ...x, title } : x)),
  })),
  setLoading: (v) => set({ isLoading: v }),
}));
