/**
 * useChat — encapsulates all chat business logic.
 * Components just call sendMessage() and read state from the store.
 */

import { useCallback } from 'react';
import { chatApi, sessionsApi } from '../services/api';
import { useChatStore } from '../store';

export function useChat() {
  const {
    sessions, activeSessionId, messages, isLoading,
    setSessions, setActiveSession, addSession, removeSession,
    setMessages, appendMessage, updateSessionTitle, setLoading,
  } = useChatStore();

  const loadSessions = useCallback(async () => {
    const { data } = await sessionsApi.list();
    setSessions(data);
  }, [setSessions]);

  const createSession = useCallback(async () => {
    const { data } = await sessionsApi.create();
    addSession(data);
    setActiveSession(data.id);
    return data;
  }, [addSession, setActiveSession]);

  const deleteSession = useCallback(async (id: string) => {
    await sessionsApi.delete(id);
    removeSession(id);
    if (activeSessionId === id) setActiveSession('');
  }, [activeSessionId, removeSession, setActiveSession]);

  const loadHistory = useCallback(async (sessionId: string) => {
    if (messages[sessionId]) return;  // already cached
    const { data } = await chatApi.getHistory(sessionId);
    setMessages(sessionId, data);
  }, [messages, setMessages]);

  const sendMessage = useCallback(async (content: string) => {
    if (!activeSessionId || isLoading) return;

    // Optimistic UI — show user message immediately
    const tempUserMsg = {
      id: `temp-${Date.now()}`, role: 'user' as const, content,
      input_tokens: 0, output_tokens: 0, latency_ms: 0,
      created_at: new Date().toISOString(),
    };
    appendMessage(activeSessionId, tempUserMsg);
    setLoading(true);

    try {
      const { data } = await chatApi.sendMessage(activeSessionId, content);
      appendMessage(activeSessionId, data.message);

      // Update sidebar title after first message
      const currentMessages = messages[activeSessionId] ?? [];
      if (currentMessages.filter(m => m.role === 'user').length <= 1) {
        updateSessionTitle(activeSessionId, content.slice(0, 60));
      }
    } catch (err) {
      console.error('sendMessage error', err);
    } finally {
      setLoading(false);
    }
  }, [activeSessionId, isLoading, appendMessage, setLoading, messages, updateSessionTitle]);

  const selectSession = useCallback(async (id: string) => {
    setActiveSession(id);
    await loadHistory(id);
  }, [setActiveSession, loadHistory]);

  const activeMessages = activeSessionId ? (messages[activeSessionId] ?? []) : [];

  return {
    sessions, activeSessionId, activeMessages, isLoading,
    loadSessions, createSession, deleteSession,
    sendMessage, selectSession,
  };
}
