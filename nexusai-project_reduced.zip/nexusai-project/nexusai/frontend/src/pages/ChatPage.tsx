import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus, Send, Trash2, LogOut, Bot, User,
  Copy, ThumbsUp, ThumbsDown, RefreshCw, Settings,
  Download, Zap
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { formatDistanceToNow } from 'date-fns';
import { useChat } from '../hooks/useChat';
import { useAuthStore } from '../store';
import type { Message } from '../store';

export default function ChatPage() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const {
    sessions, activeSessionId, activeMessages, isLoading,
    loadSessions, createSession, deleteSession, sendMessage, selectSession,
  } = useChat();

  const [input, setInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { loadSessions(); }, [loadSessions]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [activeMessages]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isLoading) return;
    if (!activeSessionId) await createSession();
    setInput('');
    if (textareaRef.current) { textareaRef.current.style.height = 'auto'; }
    await sendMessage(text);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleCopy = (msg: Message) => {
    navigator.clipboard.writeText(msg.content);
    setCopiedId(msg.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const autoResize = (el: HTMLTextAreaElement) => {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const totalTokens = activeMessages.reduce((acc, m) => acc + m.input_tokens + m.output_tokens, 0);
  const lastLatency = activeMessages.filter(m => m.role === 'assistant').at(-1)?.latency_ms;

  return (
    <div className="flex h-screen bg-gray-50 font-sans">
      {/* ── Sidebar ─────────────────────────────────────────── */}
      <aside className="w-56 flex flex-col bg-white border-r border-gray-100">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center">
              <Zap size={14} className="text-white" />
            </div>
            <span className="font-semibold text-sm text-gray-900">NexusAI</span>
          </div>
        </div>

        <button
          onClick={createSession}
          className="mx-3 my-3 flex items-center gap-2 px-3 py-2 text-sm text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Plus size={14} /> New conversation
        </button>

        <p className="px-4 pb-1 text-[10px] font-medium text-gray-400 uppercase tracking-wider">Recent</p>
        <nav className="flex-1 overflow-y-auto px-2">
          {sessions.map((s) => (
            <div
              key={s.id}
              onClick={() => selectSession(s.id)}
              className={`group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer text-sm mb-0.5 ${
                s.id === activeSessionId
                  ? 'bg-blue-50 text-blue-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <span className="truncate flex-1">{s.title}</span>
              <button
                onClick={(e) => { e.stopPropagation(); deleteSession(s.id); }}
                className="opacity-0 group-hover:opacity-100 p-0.5 hover:text-red-500 transition-opacity"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </nav>

        <div className="p-3 border-t border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-emerald-600 flex items-center justify-center text-white text-xs font-semibold">
              {user?.full_name?.[0] ?? 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-900 truncate">{user?.full_name}</p>
              <p className="text-[10px] text-gray-400">{user?.role}</p>
            </div>
            <button onClick={() => { logout(); navigate('/login'); }} className="p-1 text-gray-400 hover:text-gray-700">
              <LogOut size={13} />
            </button>
          </div>
        </div>
      </aside>

      {/* ── Main ────────────────────────────────────────────── */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="flex items-center justify-between px-6 py-3 border-b border-gray-100 bg-white">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-3 py-1 border border-gray-200 rounded-lg text-xs text-gray-500">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
              claude-sonnet-4
            </span>
            {lastLatency && (
              <span className="text-xs text-gray-400">{lastLatency}ms</span>
            )}
          </div>
          <div className="flex items-center gap-3 text-xs text-gray-400">
            {totalTokens > 0 && <span>{totalTokens.toLocaleString()} tokens</span>}
            <button className="p-1.5 hover:bg-gray-100 rounded-lg"><Settings size={15} /></button>
            <button className="p-1.5 hover:bg-gray-100 rounded-lg"><Download size={15} /></button>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {!activeSessionId && (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
                <Bot size={24} className="text-blue-600" />
              </div>
              <h2 className="text-lg font-semibold text-gray-900 mb-1">How can I help you today?</h2>
              <p className="text-sm text-gray-500 mb-6">Start a new conversation or pick one from the sidebar.</p>
              <div className="grid grid-cols-2 gap-2 max-w-md">
                {['Explain microservices vs monolith', 'Review Python code for best practices', 'Write a REST API design doc', 'SOLID principles with examples'].map((s) => (
                  <button key={s} onClick={() => { createSession().then(() => sendMessage(s)); }}
                    className="p-3 text-left text-xs text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-colors">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeMessages.map((msg) => (
            <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${
                msg.role === 'assistant' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-600 text-white text-xs font-semibold'
              }`}>
                {msg.role === 'assistant' ? <Bot size={16} /> : (user?.full_name?.[0] ?? 'U')}
              </div>
              <div className={`flex-1 min-w-0 max-w-[80%] ${msg.role === 'user' ? 'items-end' : ''} flex flex-col`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-medium text-gray-700">
                    {msg.role === 'assistant' ? 'NexusAI' : (user?.full_name ?? 'You')}
                  </span>
                  <span className="text-[10px] text-gray-400">
                    {formatDistanceToNow(new Date(msg.created_at), { addSuffix: true })}
                  </span>
                </div>
                <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white rounded-tr-sm'
                    : 'bg-white border border-gray-100 text-gray-800 rounded-tl-sm shadow-sm'
                }`}>
                  {msg.role === 'assistant'
                    ? <ReactMarkdown className="prose prose-sm max-w-none">{msg.content}</ReactMarkdown>
                    : msg.content}
                </div>
                {msg.role === 'assistant' && (
                  <div className="flex gap-1 mt-1.5">
                    {[
                      { icon: copiedId === msg.id ? <span className="text-[10px]">Copied</span> : <Copy size={11} />, label: 'Copy', action: () => handleCopy(msg) },
                      { icon: <ThumbsUp size={11} />, label: 'Good', action: () => {} },
                      { icon: <ThumbsDown size={11} />, label: 'Bad', action: () => {} },
                      { icon: <RefreshCw size={11} />, label: 'Retry', action: () => {} },
                    ].map(({ icon, label, action }) => (
                      <button key={label} onClick={action}
                        className="flex items-center gap-1 px-2 py-0.5 border border-gray-200 rounded-full text-[10px] text-gray-400 hover:text-gray-700 hover:border-gray-300 transition-colors">
                        {icon} {label}
                      </button>
                    ))}
                    {msg.output_tokens > 0 && (
                      <span className="ml-1 text-[10px] text-gray-300 flex items-center">
                        {msg.output_tokens} tokens · {msg.latency_ms}ms
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                <Bot size={16} className="text-blue-600" />
              </div>
              <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
                <div className="flex gap-1 items-center h-5">
                  {[0, 1, 2].map(i => (
                    <span key={i} className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="px-6 pb-5 pt-2">
          <div className="flex items-end gap-2 bg-white border border-gray-200 rounded-2xl px-4 py-3 shadow-sm focus-within:border-blue-300 transition-colors">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => { setInput(e.target.value); autoResize(e.target); }}
              onKeyDown={handleKey}
              placeholder="Ask anything — code, architecture, documentation…"
              rows={1}
              className="flex-1 resize-none border-none outline-none text-sm text-gray-900 placeholder-gray-400 bg-transparent leading-relaxed"
              style={{ maxHeight: 120 }}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white hover:bg-blue-700 disabled:bg-gray-200 disabled:text-gray-400 transition-colors flex-shrink-0"
            >
              <Send size={14} />
            </button>
          </div>
          <p className="text-center text-[10px] text-gray-300 mt-2">
            NexusAI may make mistakes. Review important outputs carefully.
          </p>
        </div>
      </main>
    </div>
  );
}
