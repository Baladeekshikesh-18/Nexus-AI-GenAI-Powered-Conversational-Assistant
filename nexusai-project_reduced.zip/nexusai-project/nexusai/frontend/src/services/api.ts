/**
 * Centralised API client — all HTTP calls go through here.
 * Handles auth tokens, error normalisation, and base URL config.
 */

import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL ?? 'http://localhost:8000';

export const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
  timeout: 30_000,
});

// Attach JWT on every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Global error handling
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ── Auth ──────────────────────────────────────────────────────
export const authApi = {
  login:    (email: string, password: string) =>
    api.post('/api/auth/login', { email, password }),
  register: (email: string, full_name: string, password: string) =>
    api.post('/api/auth/register', { email, full_name, password }),
  me: () => api.get('/api/auth/me'),
};

// ── Sessions ─────────────────────────────────────────────────
export const sessionsApi = {
  list:   ()           => api.get('/api/sessions/'),
  create: (title = 'New conversation') => api.post('/api/sessions/', { title }),
  delete: (id: string) => api.delete(`/api/sessions/${id}`),
};

// ── Chat ─────────────────────────────────────────────────────
export const chatApi = {
  sendMessage: (session_id: string, message: string) =>
    api.post('/api/chat/message', { session_id, message }),
  getHistory: (session_id: string) =>
    api.get(`/api/chat/${session_id}/history`),
};
