content = """from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    APP_NAME: str = "NexusAI"
    ENVIRONMENT: str = "development"
    SECRET_KEY: str = "change-me-in-production"
    ANTHROPIC_API_KEY: str = "not-used"
    GEMINI_API_KEY: str = "not-used"
    GROQ_API_KEY: str = ""
    MAX_TOKENS: int = 1024
    DATABASE_URL: str = "sqlite+aiosqlite:///./nexusai.db"
    REDIS_URL: str = "redis://localhost:6379"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480
    RATE_LIMIT_PER_MINUTE: int = 30
    ALLOWED_ORIGINS: List[str] = ["http://localhost:5173"]

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
"""

with open("app/core/config.py", "w") as f:
    f.write(content)

print("Done!")