import asyncio
from app.core.database import AsyncSessionLocal
from app.models.models import User
import hashlib
import uuid

async def main():
    async with AsyncSessionLocal() as db:
        user = User(
            id=str(uuid.uuid4()),
            email="test@test.com",
            full_name="Test User",
            hashed_password=hashlib.sha256("test123".encode()).hexdigest(),
        )
        db.add(user)
        await db.commit()
        print("✅ User created successfully!")
        print(f"   Email: test@test.com")
        print(f"   Password: test123")

asyncio.run(main())