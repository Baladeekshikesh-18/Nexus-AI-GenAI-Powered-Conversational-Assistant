import asyncio
from app.core.database import engine, Base
from app.models.models import User, ChatSession, Message

async def main():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Database tables created!")

asyncio.run(main())