import asyncio
from app.core.database import AsyncSessionLocal
from app.models.models import User
from sqlalchemy import select
import hashlib

async def main():
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User))
        users = result.scalars().all()
        print(f"Total users in DB: {len(users)}")
        for u in users:
            print(f"  Email: {u.email}")
            print(f"  Hash:  {u.hashed_password}")
            test = hashlib.sha256("test123".encode()).hexdigest()
            print(f"  Match 'test123': {u.hashed_password == test}")

asyncio.run(main())