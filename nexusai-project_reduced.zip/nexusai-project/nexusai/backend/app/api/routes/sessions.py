"""
Sessions routes — CRUD for chat sessions.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import ChatSession, Message
from app.models.schemas import SessionCreate, SessionOut

router = APIRouter()


@router.get("/", response_model=list[SessionOut])
async def list_sessions(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ChatSession)
        .where(ChatSession.user_id == current_user["user_id"])
        .order_by(ChatSession.updated_at.desc())
    )
    sessions = result.scalars().all()

    # Attach message counts
    output = []
    for s in sessions:
        count_result = await db.execute(
            select(func.count()).where(Message.session_id == s.id)
        )
        count = count_result.scalar() or 0
        out = SessionOut.model_validate(s)
        out.message_count = count
        output.append(out)
    return output


@router.post("/", response_model=SessionOut, status_code=201)
async def create_session(
    body: SessionCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    session = ChatSession(user_id=current_user["user_id"], title=body.title or "New conversation")
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return SessionOut.model_validate(session)


@router.delete("/{session_id}", status_code=204)
async def delete_session(
    session_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    session = await db.get(ChatSession, session_id)
    if not session or session.user_id != current_user["user_id"]:
        raise HTTPException(status_code=404, detail="Session not found")
    await db.delete(session)
    await db.commit()
