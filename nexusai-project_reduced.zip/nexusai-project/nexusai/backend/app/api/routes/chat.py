"""
Chat API — POST /api/chat/message
                GET  /api/chat/{session_id}/history
                POST /api/chat/{session_id}/stream  (SSE)
"""

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import json

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import ChatSession, Message
from app.models.schemas import ChatRequest, ChatResponse, MessageOut
from app.services.ai_service import ai_service

router = APIRouter()


@router.post("/message", response_model=ChatResponse)
async def send_message(
    body: ChatRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Verify session belongs to user
    session = await db.get(ChatSession, body.session_id)
    if not session or session.user_id != current_user["user_id"]:
        raise HTTPException(status_code=404, detail="Session not found")

    # Persist user message
    user_msg = Message(session_id=session.id, role="user", content=body.message)
    db.add(user_msg)
    await db.flush()

    # Build history for Claude (last 20 messages for context window control)
    result = await db.execute(
        select(Message)
        .where(Message.session_id == session.id)
        .order_by(Message.created_at)
    )
    messages = result.scalars().all()
    history = [{"role": m.role, "content": m.content} for m in messages[-20:]]

    # Call Claude
    reply, in_tok, out_tok, latency = ai_service.chat(history)

    # Persist assistant message
    ai_msg = Message(
        session_id=session.id,
        role="assistant",
        content=reply,
        input_tokens=in_tok,
        output_tokens=out_tok,
        latency_ms=latency,
    )
    db.add(ai_msg)

    # Auto-update session title from first user message
    if session.title == "New conversation":
        session.title = body.message[:60] + ("…" if len(body.message) > 60 else "")

    await db.commit()
    await db.refresh(ai_msg)

    return ChatResponse(session_id=session.id, message=MessageOut.model_validate(ai_msg))


@router.get("/{session_id}/history", response_model=list[MessageOut])
async def get_history(
    session_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    session = await db.get(ChatSession, session_id)
    if not session or session.user_id != current_user["user_id"]:
        raise HTTPException(status_code=404, detail="Session not found")

    result = await db.execute(
        select(Message).where(Message.session_id == session_id).order_by(Message.created_at)
    )
    return result.scalars().all()


@router.post("/{session_id}/stream")
async def stream_message(
    session_id: str,
    body: ChatRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Server-Sent Events streaming endpoint."""
    session = await db.get(ChatSession, session_id)
    if not session or session.user_id != current_user["user_id"]:
        raise HTTPException(status_code=404, detail="Session not found")

    result = await db.execute(
        select(Message).where(Message.session_id == session_id).order_by(Message.created_at)
    )
    existing = result.scalars().all()
    history = [{"role": m.role, "content": m.content} for m in existing[-20:]]
    history.append({"role": "user", "content": body.message})

    def event_stream():
        full_reply = []
        for chunk in ai_service.stream(history):
            full_reply.append(chunk)
            yield f"data: {json.dumps({'chunk': chunk})}\n\n"
        yield f"data: {json.dumps({'done': True, 'full': ''.join(full_reply)})}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")
