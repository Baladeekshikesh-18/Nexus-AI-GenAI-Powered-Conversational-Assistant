"""
Database models: User, ChatSession, Message.
"""

import uuid
from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, Integer, ForeignKey, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id:           Mapped[str]      = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    email:        Mapped[str]      = mapped_column(String(255), unique=True, nullable=False)
    full_name:    Mapped[str]      = mapped_column(String(255), nullable=False)
    hashed_password: Mapped[str]  = mapped_column(String(255), nullable=False)
    role:         Mapped[str]      = mapped_column(String(50), default="user")
    created_at:   Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    sessions: Mapped[list["ChatSession"]] = relationship("ChatSession", back_populates="user", cascade="all, delete-orphan")


class ChatSession(Base):
    __tablename__ = "chat_sessions"

    id:         Mapped[str]      = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id:    Mapped[str]      = mapped_column(ForeignKey("users.id"), nullable=False)
    title:      Mapped[str]      = mapped_column(String(255), default="New conversation")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    user:     Mapped["User"]          = relationship("User", back_populates="sessions")
    messages: Mapped[list["Message"]] = relationship("Message", back_populates="session", cascade="all, delete-orphan", order_by="Message.created_at")


class Message(Base):
    __tablename__ = "messages"

    id:           Mapped[str]      = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id:   Mapped[str]      = mapped_column(ForeignKey("chat_sessions.id"), nullable=False)
    role:         Mapped[str]      = mapped_column(SAEnum("user", "assistant", name="message_role"), nullable=False)
    content:      Mapped[str]      = mapped_column(Text, nullable=False)
    input_tokens: Mapped[int]      = mapped_column(Integer, default=0)
    output_tokens:Mapped[int]      = mapped_column(Integer, default=0)
    latency_ms:   Mapped[int]      = mapped_column(Integer, default=0)
    created_at:   Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    session: Mapped["ChatSession"] = relationship("ChatSession", back_populates="messages")
