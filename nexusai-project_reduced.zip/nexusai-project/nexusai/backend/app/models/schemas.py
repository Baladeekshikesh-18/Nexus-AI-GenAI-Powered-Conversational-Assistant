"""
Pydantic schemas for request/response validation.
"""

from pydantic import BaseModel, EmailStr
from typing import Literal, Optional
from datetime import datetime


# ── Auth ──────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    full_name: str
    role: str

class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: str
    password: str


# ── Chat ──────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    session_id: str
    message: str

class MessageOut(BaseModel):
    id: str
    role: Literal["user", "assistant"]
    content: str
    input_tokens: int
    output_tokens: int
    latency_ms: int
    created_at: datetime

    class Config:
        from_attributes = True

class ChatResponse(BaseModel):
    session_id: str
    message: MessageOut


# ── Sessions ─────────────────────────────────────────────────
class SessionCreate(BaseModel):
    title: Optional[str] = "New conversation"

class SessionOut(BaseModel):
    id: str
    title: str
    created_at: datetime
    updated_at: datetime
    message_count: Optional[int] = 0

    class Config:
        from_attributes = True
