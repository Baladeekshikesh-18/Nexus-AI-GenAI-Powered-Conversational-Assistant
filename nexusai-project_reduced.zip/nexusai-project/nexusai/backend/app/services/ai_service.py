import time
import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

SYSTEM_PROMPT = """You are NexusAI, an enterprise AI assistant for software engineers.
Be concise, technically precise, and professional.
Format code inside triple-backtick blocks with the language name."""


class AIService:

    @staticmethod
    def chat(history: list[dict]) -> tuple[str, int, int, int]:
        t0 = time.monotonic()

        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history

        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=messages,
            max_tokens=1024,
        )

        latency_ms = int((time.monotonic() - t0) * 1000)
        reply = response.choices[0].message.content
        input_tokens = response.usage.prompt_tokens
        output_tokens = response.usage.completion_tokens

        return reply, input_tokens, output_tokens, latency_ms


ai_service = AIService()