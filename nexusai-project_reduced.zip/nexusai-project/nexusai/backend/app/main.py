"""
NexusAI — Enterprise GenAI Chatbot
FastAPI Backend Entry Point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app.api.routes import chat, auth, sessions, health
from app.middleware.logging import LoggingMiddleware
from app.middleware.rate_limit import RateLimitMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"🚀 NexusAI API starting — env: {settings.ENVIRONMENT}")
    yield
    print("🛑 NexusAI API shutting down")


app = FastAPI(
    title="NexusAI API",
    description="Enterprise GenAI Chatbot powered by Claude",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# ── Middleware ────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(LoggingMiddleware)
app.add_middleware(RateLimitMiddleware)

# ── Routers ───────────────────────────────────────────────────
app.include_router(health.router, prefix="/api", tags=["Health"])
app.include_router(auth.router,    prefix="/api/auth",     tags=["Auth"])
app.include_router(sessions.router,prefix="/api/sessions", tags=["Sessions"])
app.include_router(chat.router,    prefix="/api/chat",     tags=["Chat"])
