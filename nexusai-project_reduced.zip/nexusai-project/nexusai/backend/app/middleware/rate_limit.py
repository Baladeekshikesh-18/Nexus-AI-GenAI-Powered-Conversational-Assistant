"""
Simple in-memory rate limiter (swap for Redis in production).
"""

import time
from collections import defaultdict
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.config import settings

_store: dict[str, list[float]] = defaultdict(list)
WINDOW = 60  # seconds


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Skip health checks
        if request.url.path == "/api/health":
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        now = time.time()
        hits = [t for t in _store[client_ip] if now - t < WINDOW]
        hits.append(now)
        _store[client_ip] = hits

        if len(hits) > settings.RATE_LIMIT_PER_MINUTE:
            return JSONResponse(
                status_code=429,
                content={"detail": f"Rate limit exceeded — max {settings.RATE_LIMIT_PER_MINUTE} requests/minute"},
            )
        return await call_next(request)
